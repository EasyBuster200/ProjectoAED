package Exceptions;

public class auctionIdAlreadyRegisteredException extends Exception{
   
	private static final long serialVersionUID = 1L;

	public auctionIdAlreadyRegisteredException() {
        super("\nLeilao existente.");
    }
}
