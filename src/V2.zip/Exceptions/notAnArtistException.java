package Exceptions;

public class notAnArtistException extends Exception {
    
	private static final long serialVersionUID = 1L;

	public notAnArtistException() {
        super("\nArtista inexistente.");
    }
}
