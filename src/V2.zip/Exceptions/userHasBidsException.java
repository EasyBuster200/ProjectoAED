package Exceptions;

public class userHasBidsException extends Exception {
    public userHasBidsException() {
        super ("\nUtilizador com propostas submetidas.");
    }
}
