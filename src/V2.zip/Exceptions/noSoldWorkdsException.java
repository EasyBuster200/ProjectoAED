package Exceptions;

public class noSoldWorkdsException extends Exception{
    
	private static final long serialVersionUID = 1L;

	public noSoldWorkdsException() {
        super("\nNao existem obras ja vendidas em leilao.");
    }
}
