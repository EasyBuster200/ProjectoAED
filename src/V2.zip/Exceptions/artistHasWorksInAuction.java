package Exceptions;

public class artistHasWorksInAuction extends Exception {
    public artistHasWorksInAuction() {
        super("\nArtista com obras em leilao.");
    }
}
